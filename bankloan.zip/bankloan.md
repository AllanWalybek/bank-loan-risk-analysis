```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.style as style
import seaborn as sns
import itertools
%matplotlib inline
import warnings
warnings.filterwarnings('ignore')
```


```python
applicationdf = pd.read_csv('./data/application_data.csv')
```


```python
previousdf = pd.read_csv('./data/previous_application.csv')
```


```python
columnsdf = pd.read_csv('./data/columns_description.csv')
```


```python
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)
pd.set_option('display.expand_frame_repr', False)
```


```python
applicationdf.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SK_ID_CURR</th>
      <th>TARGET</th>
      <th>NAME_CONTRACT_TYPE</th>
      <th>CODE_GENDER</th>
      <th>FLAG_OWN_CAR</th>
      <th>FLAG_OWN_REALTY</th>
      <th>CNT_CHILDREN</th>
      <th>AMT_INCOME_TOTAL</th>
      <th>AMT_CREDIT</th>
      <th>AMT_ANNUITY</th>
      <th>AMT_GOODS_PRICE</th>
      <th>NAME_TYPE_SUITE</th>
      <th>NAME_INCOME_TYPE</th>
      <th>NAME_EDUCATION_TYPE</th>
      <th>NAME_FAMILY_STATUS</th>
      <th>NAME_HOUSING_TYPE</th>
      <th>REGION_POPULATION_RELATIVE</th>
      <th>DAYS_BIRTH</th>
      <th>DAYS_EMPLOYED</th>
      <th>DAYS_REGISTRATION</th>
      <th>DAYS_ID_PUBLISH</th>
      <th>OWN_CAR_AGE</th>
      <th>FLAG_MOBIL</th>
      <th>FLAG_EMP_PHONE</th>
      <th>FLAG_WORK_PHONE</th>
      <th>FLAG_CONT_MOBILE</th>
      <th>FLAG_PHONE</th>
      <th>FLAG_EMAIL</th>
      <th>OCCUPATION_TYPE</th>
      <th>CNT_FAM_MEMBERS</th>
      <th>REGION_RATING_CLIENT</th>
      <th>REGION_RATING_CLIENT_W_CITY</th>
      <th>WEEKDAY_APPR_PROCESS_START</th>
      <th>HOUR_APPR_PROCESS_START</th>
      <th>REG_REGION_NOT_LIVE_REGION</th>
      <th>REG_REGION_NOT_WORK_REGION</th>
      <th>LIVE_REGION_NOT_WORK_REGION</th>
      <th>REG_CITY_NOT_LIVE_CITY</th>
      <th>REG_CITY_NOT_WORK_CITY</th>
      <th>LIVE_CITY_NOT_WORK_CITY</th>
      <th>ORGANIZATION_TYPE</th>
      <th>EXT_SOURCE_1</th>
      <th>EXT_SOURCE_2</th>
      <th>EXT_SOURCE_3</th>
      <th>APARTMENTS_AVG</th>
      <th>BASEMENTAREA_AVG</th>
      <th>YEARS_BEGINEXPLUATATION_AVG</th>
      <th>YEARS_BUILD_AVG</th>
      <th>COMMONAREA_AVG</th>
      <th>ELEVATORS_AVG</th>
      <th>ENTRANCES_AVG</th>
      <th>FLOORSMAX_AVG</th>
      <th>FLOORSMIN_AVG</th>
      <th>LANDAREA_AVG</th>
      <th>LIVINGAPARTMENTS_AVG</th>
      <th>LIVINGAREA_AVG</th>
      <th>NONLIVINGAPARTMENTS_AVG</th>
      <th>NONLIVINGAREA_AVG</th>
      <th>APARTMENTS_MODE</th>
      <th>BASEMENTAREA_MODE</th>
      <th>YEARS_BEGINEXPLUATATION_MODE</th>
      <th>YEARS_BUILD_MODE</th>
      <th>COMMONAREA_MODE</th>
      <th>ELEVATORS_MODE</th>
      <th>ENTRANCES_MODE</th>
      <th>FLOORSMAX_MODE</th>
      <th>FLOORSMIN_MODE</th>
      <th>LANDAREA_MODE</th>
      <th>LIVINGAPARTMENTS_MODE</th>
      <th>LIVINGAREA_MODE</th>
      <th>NONLIVINGAPARTMENTS_MODE</th>
      <th>NONLIVINGAREA_MODE</th>
      <th>APARTMENTS_MEDI</th>
      <th>BASEMENTAREA_MEDI</th>
      <th>YEARS_BEGINEXPLUATATION_MEDI</th>
      <th>YEARS_BUILD_MEDI</th>
      <th>COMMONAREA_MEDI</th>
      <th>ELEVATORS_MEDI</th>
      <th>ENTRANCES_MEDI</th>
      <th>FLOORSMAX_MEDI</th>
      <th>FLOORSMIN_MEDI</th>
      <th>LANDAREA_MEDI</th>
      <th>LIVINGAPARTMENTS_MEDI</th>
      <th>LIVINGAREA_MEDI</th>
      <th>NONLIVINGAPARTMENTS_MEDI</th>
      <th>NONLIVINGAREA_MEDI</th>
      <th>FONDKAPREMONT_MODE</th>
      <th>HOUSETYPE_MODE</th>
      <th>TOTALAREA_MODE</th>
      <th>WALLSMATERIAL_MODE</th>
      <th>EMERGENCYSTATE_MODE</th>
      <th>OBS_30_CNT_SOCIAL_CIRCLE</th>
      <th>DEF_30_CNT_SOCIAL_CIRCLE</th>
      <th>OBS_60_CNT_SOCIAL_CIRCLE</th>
      <th>DEF_60_CNT_SOCIAL_CIRCLE</th>
      <th>DAYS_LAST_PHONE_CHANGE</th>
      <th>FLAG_DOCUMENT_2</th>
      <th>FLAG_DOCUMENT_3</th>
      <th>FLAG_DOCUMENT_4</th>
      <th>FLAG_DOCUMENT_5</th>
      <th>FLAG_DOCUMENT_6</th>
      <th>FLAG_DOCUMENT_7</th>
      <th>FLAG_DOCUMENT_8</th>
      <th>FLAG_DOCUMENT_9</th>
      <th>FLAG_DOCUMENT_10</th>
      <th>FLAG_DOCUMENT_11</th>
      <th>FLAG_DOCUMENT_12</th>
      <th>FLAG_DOCUMENT_13</th>
      <th>FLAG_DOCUMENT_14</th>
      <th>FLAG_DOCUMENT_15</th>
      <th>FLAG_DOCUMENT_16</th>
      <th>FLAG_DOCUMENT_17</th>
      <th>FLAG_DOCUMENT_18</th>
      <th>FLAG_DOCUMENT_19</th>
      <th>FLAG_DOCUMENT_20</th>
      <th>FLAG_DOCUMENT_21</th>
      <th>AMT_REQ_CREDIT_BUREAU_HOUR</th>
      <th>AMT_REQ_CREDIT_BUREAU_DAY</th>
      <th>AMT_REQ_CREDIT_BUREAU_WEEK</th>
      <th>AMT_REQ_CREDIT_BUREAU_MON</th>
      <th>AMT_REQ_CREDIT_BUREAU_QRT</th>
      <th>AMT_REQ_CREDIT_BUREAU_YEAR</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>100002</td>
      <td>1</td>
      <td>Cash loans</td>
      <td>M</td>
      <td>N</td>
      <td>Y</td>
      <td>0</td>
      <td>202500.0</td>
      <td>406597.5</td>
      <td>24700.5</td>
      <td>351000.0</td>
      <td>Unaccompanied</td>
      <td>Working</td>
      <td>Secondary / secondary special</td>
      <td>Single / not married</td>
      <td>House / apartment</td>
      <td>0.018801</td>
      <td>-9461</td>
      <td>-637</td>
      <td>-3648.0</td>
      <td>-2120</td>
      <td>NaN</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>Laborers</td>
      <td>1.0</td>
      <td>2</td>
      <td>2</td>
      <td>WEDNESDAY</td>
      <td>10</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Business Entity Type 3</td>
      <td>0.083037</td>
      <td>0.262949</td>
      <td>0.139376</td>
      <td>0.0247</td>
      <td>0.0369</td>
      <td>0.9722</td>
      <td>0.6192</td>
      <td>0.0143</td>
      <td>0.00</td>
      <td>0.0690</td>
      <td>0.0833</td>
      <td>0.1250</td>
      <td>0.0369</td>
      <td>0.0202</td>
      <td>0.0190</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0252</td>
      <td>0.0383</td>
      <td>0.9722</td>
      <td>0.6341</td>
      <td>0.0144</td>
      <td>0.0000</td>
      <td>0.0690</td>
      <td>0.0833</td>
      <td>0.1250</td>
      <td>0.0377</td>
      <td>0.022</td>
      <td>0.0198</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0250</td>
      <td>0.0369</td>
      <td>0.9722</td>
      <td>0.6243</td>
      <td>0.0144</td>
      <td>0.00</td>
      <td>0.0690</td>
      <td>0.0833</td>
      <td>0.1250</td>
      <td>0.0375</td>
      <td>0.0205</td>
      <td>0.0193</td>
      <td>0.0000</td>
      <td>0.00</td>
      <td>reg oper account</td>
      <td>block of flats</td>
      <td>0.0149</td>
      <td>Stone, brick</td>
      <td>No</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>-1134.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>100003</td>
      <td>0</td>
      <td>Cash loans</td>
      <td>F</td>
      <td>N</td>
      <td>N</td>
      <td>0</td>
      <td>270000.0</td>
      <td>1293502.5</td>
      <td>35698.5</td>
      <td>1129500.0</td>
      <td>Family</td>
      <td>State servant</td>
      <td>Higher education</td>
      <td>Married</td>
      <td>House / apartment</td>
      <td>0.003541</td>
      <td>-16765</td>
      <td>-1188</td>
      <td>-1186.0</td>
      <td>-291</td>
      <td>NaN</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>Core staff</td>
      <td>2.0</td>
      <td>1</td>
      <td>1</td>
      <td>MONDAY</td>
      <td>11</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>School</td>
      <td>0.311267</td>
      <td>0.622246</td>
      <td>NaN</td>
      <td>0.0959</td>
      <td>0.0529</td>
      <td>0.9851</td>
      <td>0.7960</td>
      <td>0.0605</td>
      <td>0.08</td>
      <td>0.0345</td>
      <td>0.2917</td>
      <td>0.3333</td>
      <td>0.0130</td>
      <td>0.0773</td>
      <td>0.0549</td>
      <td>0.0039</td>
      <td>0.0098</td>
      <td>0.0924</td>
      <td>0.0538</td>
      <td>0.9851</td>
      <td>0.8040</td>
      <td>0.0497</td>
      <td>0.0806</td>
      <td>0.0345</td>
      <td>0.2917</td>
      <td>0.3333</td>
      <td>0.0128</td>
      <td>0.079</td>
      <td>0.0554</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0968</td>
      <td>0.0529</td>
      <td>0.9851</td>
      <td>0.7987</td>
      <td>0.0608</td>
      <td>0.08</td>
      <td>0.0345</td>
      <td>0.2917</td>
      <td>0.3333</td>
      <td>0.0132</td>
      <td>0.0787</td>
      <td>0.0558</td>
      <td>0.0039</td>
      <td>0.01</td>
      <td>reg oper account</td>
      <td>block of flats</td>
      <td>0.0714</td>
      <td>Block</td>
      <td>No</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>-828.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>100004</td>
      <td>0</td>
      <td>Revolving loans</td>
      <td>M</td>
      <td>Y</td>
      <td>Y</td>
      <td>0</td>
      <td>67500.0</td>
      <td>135000.0</td>
      <td>6750.0</td>
      <td>135000.0</td>
      <td>Unaccompanied</td>
      <td>Working</td>
      <td>Secondary / secondary special</td>
      <td>Single / not married</td>
      <td>House / apartment</td>
      <td>0.010032</td>
      <td>-19046</td>
      <td>-225</td>
      <td>-4260.0</td>
      <td>-2531</td>
      <td>26.0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>Laborers</td>
      <td>1.0</td>
      <td>2</td>
      <td>2</td>
      <td>MONDAY</td>
      <td>9</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Government</td>
      <td>NaN</td>
      <td>0.555912</td>
      <td>0.729567</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>-815.0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>100006</td>
      <td>0</td>
      <td>Cash loans</td>
      <td>F</td>
      <td>N</td>
      <td>Y</td>
      <td>0</td>
      <td>135000.0</td>
      <td>312682.5</td>
      <td>29686.5</td>
      <td>297000.0</td>
      <td>Unaccompanied</td>
      <td>Working</td>
      <td>Secondary / secondary special</td>
      <td>Civil marriage</td>
      <td>House / apartment</td>
      <td>0.008019</td>
      <td>-19005</td>
      <td>-3039</td>
      <td>-9833.0</td>
      <td>-2437</td>
      <td>NaN</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>Laborers</td>
      <td>2.0</td>
      <td>2</td>
      <td>2</td>
      <td>WEDNESDAY</td>
      <td>17</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Business Entity Type 3</td>
      <td>NaN</td>
      <td>0.650442</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>-617.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>100007</td>
      <td>0</td>
      <td>Cash loans</td>
      <td>M</td>
      <td>N</td>
      <td>Y</td>
      <td>0</td>
      <td>121500.0</td>
      <td>513000.0</td>
      <td>21865.5</td>
      <td>513000.0</td>
      <td>Unaccompanied</td>
      <td>Working</td>
      <td>Secondary / secondary special</td>
      <td>Single / not married</td>
      <td>House / apartment</td>
      <td>0.028663</td>
      <td>-19932</td>
      <td>-3038</td>
      <td>-4311.0</td>
      <td>-3458</td>
      <td>NaN</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>Core staff</td>
      <td>1.0</td>
      <td>2</td>
      <td>2</td>
      <td>THURSDAY</td>
      <td>11</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Religion</td>
      <td>NaN</td>
      <td>0.322738</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>-1106.0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
previousdf.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SK_ID_PREV</th>
      <th>SK_ID_CURR</th>
      <th>NAME_CONTRACT_TYPE</th>
      <th>AMT_ANNUITY</th>
      <th>AMT_APPLICATION</th>
      <th>AMT_CREDIT</th>
      <th>AMT_DOWN_PAYMENT</th>
      <th>AMT_GOODS_PRICE</th>
      <th>WEEKDAY_APPR_PROCESS_START</th>
      <th>HOUR_APPR_PROCESS_START</th>
      <th>FLAG_LAST_APPL_PER_CONTRACT</th>
      <th>NFLAG_LAST_APPL_IN_DAY</th>
      <th>RATE_DOWN_PAYMENT</th>
      <th>RATE_INTEREST_PRIMARY</th>
      <th>RATE_INTEREST_PRIVILEGED</th>
      <th>NAME_CASH_LOAN_PURPOSE</th>
      <th>NAME_CONTRACT_STATUS</th>
      <th>DAYS_DECISION</th>
      <th>NAME_PAYMENT_TYPE</th>
      <th>CODE_REJECT_REASON</th>
      <th>NAME_TYPE_SUITE</th>
      <th>NAME_CLIENT_TYPE</th>
      <th>NAME_GOODS_CATEGORY</th>
      <th>NAME_PORTFOLIO</th>
      <th>NAME_PRODUCT_TYPE</th>
      <th>CHANNEL_TYPE</th>
      <th>SELLERPLACE_AREA</th>
      <th>NAME_SELLER_INDUSTRY</th>
      <th>CNT_PAYMENT</th>
      <th>NAME_YIELD_GROUP</th>
      <th>PRODUCT_COMBINATION</th>
      <th>DAYS_FIRST_DRAWING</th>
      <th>DAYS_FIRST_DUE</th>
      <th>DAYS_LAST_DUE_1ST_VERSION</th>
      <th>DAYS_LAST_DUE</th>
      <th>DAYS_TERMINATION</th>
      <th>NFLAG_INSURED_ON_APPROVAL</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2030495</td>
      <td>271877</td>
      <td>Consumer loans</td>
      <td>1730.430</td>
      <td>17145.0</td>
      <td>17145.0</td>
      <td>0.0</td>
      <td>17145.0</td>
      <td>SATURDAY</td>
      <td>15</td>
      <td>Y</td>
      <td>1</td>
      <td>0.0</td>
      <td>0.182832</td>
      <td>0.867336</td>
      <td>XAP</td>
      <td>Approved</td>
      <td>-73</td>
      <td>Cash through the bank</td>
      <td>XAP</td>
      <td>NaN</td>
      <td>Repeater</td>
      <td>Mobile</td>
      <td>POS</td>
      <td>XNA</td>
      <td>Country-wide</td>
      <td>35</td>
      <td>Connectivity</td>
      <td>12.0</td>
      <td>middle</td>
      <td>POS mobile with interest</td>
      <td>365243.0</td>
      <td>-42.0</td>
      <td>300.0</td>
      <td>-42.0</td>
      <td>-37.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2802425</td>
      <td>108129</td>
      <td>Cash loans</td>
      <td>25188.615</td>
      <td>607500.0</td>
      <td>679671.0</td>
      <td>NaN</td>
      <td>607500.0</td>
      <td>THURSDAY</td>
      <td>11</td>
      <td>Y</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>XNA</td>
      <td>Approved</td>
      <td>-164</td>
      <td>XNA</td>
      <td>XAP</td>
      <td>Unaccompanied</td>
      <td>Repeater</td>
      <td>XNA</td>
      <td>Cash</td>
      <td>x-sell</td>
      <td>Contact center</td>
      <td>-1</td>
      <td>XNA</td>
      <td>36.0</td>
      <td>low_action</td>
      <td>Cash X-Sell: low</td>
      <td>365243.0</td>
      <td>-134.0</td>
      <td>916.0</td>
      <td>365243.0</td>
      <td>365243.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2523466</td>
      <td>122040</td>
      <td>Cash loans</td>
      <td>15060.735</td>
      <td>112500.0</td>
      <td>136444.5</td>
      <td>NaN</td>
      <td>112500.0</td>
      <td>TUESDAY</td>
      <td>11</td>
      <td>Y</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>XNA</td>
      <td>Approved</td>
      <td>-301</td>
      <td>Cash through the bank</td>
      <td>XAP</td>
      <td>Spouse, partner</td>
      <td>Repeater</td>
      <td>XNA</td>
      <td>Cash</td>
      <td>x-sell</td>
      <td>Credit and cash offices</td>
      <td>-1</td>
      <td>XNA</td>
      <td>12.0</td>
      <td>high</td>
      <td>Cash X-Sell: high</td>
      <td>365243.0</td>
      <td>-271.0</td>
      <td>59.0</td>
      <td>365243.0</td>
      <td>365243.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2819243</td>
      <td>176158</td>
      <td>Cash loans</td>
      <td>47041.335</td>
      <td>450000.0</td>
      <td>470790.0</td>
      <td>NaN</td>
      <td>450000.0</td>
      <td>MONDAY</td>
      <td>7</td>
      <td>Y</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>XNA</td>
      <td>Approved</td>
      <td>-512</td>
      <td>Cash through the bank</td>
      <td>XAP</td>
      <td>NaN</td>
      <td>Repeater</td>
      <td>XNA</td>
      <td>Cash</td>
      <td>x-sell</td>
      <td>Credit and cash offices</td>
      <td>-1</td>
      <td>XNA</td>
      <td>12.0</td>
      <td>middle</td>
      <td>Cash X-Sell: middle</td>
      <td>365243.0</td>
      <td>-482.0</td>
      <td>-152.0</td>
      <td>-182.0</td>
      <td>-177.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1784265</td>
      <td>202054</td>
      <td>Cash loans</td>
      <td>31924.395</td>
      <td>337500.0</td>
      <td>404055.0</td>
      <td>NaN</td>
      <td>337500.0</td>
      <td>THURSDAY</td>
      <td>9</td>
      <td>Y</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Repairs</td>
      <td>Refused</td>
      <td>-781</td>
      <td>Cash through the bank</td>
      <td>HC</td>
      <td>NaN</td>
      <td>Repeater</td>
      <td>XNA</td>
      <td>Cash</td>
      <td>walk-in</td>
      <td>Credit and cash offices</td>
      <td>-1</td>
      <td>XNA</td>
      <td>24.0</td>
      <td>high</td>
      <td>Cash Street: high</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
columnsdf.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Table</th>
      <th>Row</th>
      <th>Description</th>
      <th>Special</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>application_data</td>
      <td>SK_ID_CURR</td>
      <td>ID of loan in our sample</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>application_data</td>
      <td>TARGET</td>
      <td>Target variable (1 - client with payment diffi...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5</td>
      <td>application_data</td>
      <td>NAME_CONTRACT_TYPE</td>
      <td>Identification if loan is cash or revolving</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>6</td>
      <td>application_data</td>
      <td>CODE_GENDER</td>
      <td>Gender of the client</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7</td>
      <td>application_data</td>
      <td>FLAG_OWN_CAR</td>
      <td>Flag if the client owns a car</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
print("Database dimension - applicationdf     :",applicationdf.shape)
print("Database dimension - previousdf        :",previousdf.shape)
print("Database size - applicationdf          :",applicationdf.size)
print("Database size - previousdf             :",previousdf.size)
```

    Database dimension - applicationdf     : (307511, 122)
    Database dimension - previousdf        : (1670214, 37)
    Database size - applicationdf          : 37516342
    Database size - previousdf             : 61797918
    


```python
applicationdf.info(verbose=True)
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 307511 entries, 0 to 307510
    Data columns (total 122 columns):
     #    Column                        Dtype  
    ---   ------                        -----  
     0    SK_ID_CURR                    int64  
     1    TARGET                        int64  
     2    NAME_CONTRACT_TYPE            object 
     3    CODE_GENDER                   object 
     4    FLAG_OWN_CAR                  object 
     5    FLAG_OWN_REALTY               object 
     6    CNT_CHILDREN                  int64  
     7    AMT_INCOME_TOTAL              float64
     8    AMT_CREDIT                    float64
     9    AMT_ANNUITY                   float64
     10   AMT_GOODS_PRICE               float64
     11   NAME_TYPE_SUITE               object 
     12   NAME_INCOME_TYPE              object 
     13   NAME_EDUCATION_TYPE           object 
     14   NAME_FAMILY_STATUS            object 
     15   NAME_HOUSING_TYPE             object 
     16   REGION_POPULATION_RELATIVE    float64
     17   DAYS_BIRTH                    int64  
     18   DAYS_EMPLOYED                 int64  
     19   DAYS_REGISTRATION             float64
     20   DAYS_ID_PUBLISH               int64  
     21   OWN_CAR_AGE                   float64
     22   FLAG_MOBIL                    int64  
     23   FLAG_EMP_PHONE                int64  
     24   FLAG_WORK_PHONE               int64  
     25   FLAG_CONT_MOBILE              int64  
     26   FLAG_PHONE                    int64  
     27   FLAG_EMAIL                    int64  
     28   OCCUPATION_TYPE               object 
     29   CNT_FAM_MEMBERS               float64
     30   REGION_RATING_CLIENT          int64  
     31   REGION_RATING_CLIENT_W_CITY   int64  
     32   WEEKDAY_APPR_PROCESS_START    object 
     33   HOUR_APPR_PROCESS_START       int64  
     34   REG_REGION_NOT_LIVE_REGION    int64  
     35   REG_REGION_NOT_WORK_REGION    int64  
     36   LIVE_REGION_NOT_WORK_REGION   int64  
     37   REG_CITY_NOT_LIVE_CITY        int64  
     38   REG_CITY_NOT_WORK_CITY        int64  
     39   LIVE_CITY_NOT_WORK_CITY       int64  
     40   ORGANIZATION_TYPE             object 
     41   EXT_SOURCE_1                  float64
     42   EXT_SOURCE_2                  float64
     43   EXT_SOURCE_3                  float64
     44   APARTMENTS_AVG                float64
     45   BASEMENTAREA_AVG              float64
     46   YEARS_BEGINEXPLUATATION_AVG   float64
     47   YEARS_BUILD_AVG               float64
     48   COMMONAREA_AVG                float64
     49   ELEVATORS_AVG                 float64
     50   ENTRANCES_AVG                 float64
     51   FLOORSMAX_AVG                 float64
     52   FLOORSMIN_AVG                 float64
     53   LANDAREA_AVG                  float64
     54   LIVINGAPARTMENTS_AVG          float64
     55   LIVINGAREA_AVG                float64
     56   NONLIVINGAPARTMENTS_AVG       float64
     57   NONLIVINGAREA_AVG             float64
     58   APARTMENTS_MODE               float64
     59   BASEMENTAREA_MODE             float64
     60   YEARS_BEGINEXPLUATATION_MODE  float64
     61   YEARS_BUILD_MODE              float64
     62   COMMONAREA_MODE               float64
     63   ELEVATORS_MODE                float64
     64   ENTRANCES_MODE                float64
     65   FLOORSMAX_MODE                float64
     66   FLOORSMIN_MODE                float64
     67   LANDAREA_MODE                 float64
     68   LIVINGAPARTMENTS_MODE         float64
     69   LIVINGAREA_MODE               float64
     70   NONLIVINGAPARTMENTS_MODE      float64
     71   NONLIVINGAREA_MODE            float64
     72   APARTMENTS_MEDI               float64
     73   BASEMENTAREA_MEDI             float64
     74   YEARS_BEGINEXPLUATATION_MEDI  float64
     75   YEARS_BUILD_MEDI              float64
     76   COMMONAREA_MEDI               float64
     77   ELEVATORS_MEDI                float64
     78   ENTRANCES_MEDI                float64
     79   FLOORSMAX_MEDI                float64
     80   FLOORSMIN_MEDI                float64
     81   LANDAREA_MEDI                 float64
     82   LIVINGAPARTMENTS_MEDI         float64
     83   LIVINGAREA_MEDI               float64
     84   NONLIVINGAPARTMENTS_MEDI      float64
     85   NONLIVINGAREA_MEDI            float64
     86   FONDKAPREMONT_MODE            object 
     87   HOUSETYPE_MODE                object 
     88   TOTALAREA_MODE                float64
     89   WALLSMATERIAL_MODE            object 
     90   EMERGENCYSTATE_MODE           object 
     91   OBS_30_CNT_SOCIAL_CIRCLE      float64
     92   DEF_30_CNT_SOCIAL_CIRCLE      float64
     93   OBS_60_CNT_SOCIAL_CIRCLE      float64
     94   DEF_60_CNT_SOCIAL_CIRCLE      float64
     95   DAYS_LAST_PHONE_CHANGE        float64
     96   FLAG_DOCUMENT_2               int64  
     97   FLAG_DOCUMENT_3               int64  
     98   FLAG_DOCUMENT_4               int64  
     99   FLAG_DOCUMENT_5               int64  
     100  FLAG_DOCUMENT_6               int64  
     101  FLAG_DOCUMENT_7               int64  
     102  FLAG_DOCUMENT_8               int64  
     103  FLAG_DOCUMENT_9               int64  
     104  FLAG_DOCUMENT_10              int64  
     105  FLAG_DOCUMENT_11              int64  
     106  FLAG_DOCUMENT_12              int64  
     107  FLAG_DOCUMENT_13              int64  
     108  FLAG_DOCUMENT_14              int64  
     109  FLAG_DOCUMENT_15              int64  
     110  FLAG_DOCUMENT_16              int64  
     111  FLAG_DOCUMENT_17              int64  
     112  FLAG_DOCUMENT_18              int64  
     113  FLAG_DOCUMENT_19              int64  
     114  FLAG_DOCUMENT_20              int64  
     115  FLAG_DOCUMENT_21              int64  
     116  AMT_REQ_CREDIT_BUREAU_HOUR    float64
     117  AMT_REQ_CREDIT_BUREAU_DAY     float64
     118  AMT_REQ_CREDIT_BUREAU_WEEK    float64
     119  AMT_REQ_CREDIT_BUREAU_MON     float64
     120  AMT_REQ_CREDIT_BUREAU_QRT     float64
     121  AMT_REQ_CREDIT_BUREAU_YEAR    float64
    dtypes: float64(65), int64(41), object(16)
    memory usage: 286.2+ MB
    


```python
previousdf.info(verbose=True)
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1670214 entries, 0 to 1670213
    Data columns (total 37 columns):
     #   Column                       Non-Null Count    Dtype  
    ---  ------                       --------------    -----  
     0   SK_ID_PREV                   1670214 non-null  int64  
     1   SK_ID_CURR                   1670214 non-null  int64  
     2   NAME_CONTRACT_TYPE           1670214 non-null  object 
     3   AMT_ANNUITY                  1297979 non-null  float64
     4   AMT_APPLICATION              1670214 non-null  float64
     5   AMT_CREDIT                   1670213 non-null  float64
     6   AMT_DOWN_PAYMENT             774370 non-null   float64
     7   AMT_GOODS_PRICE              1284699 non-null  float64
     8   WEEKDAY_APPR_PROCESS_START   1670214 non-null  object 
     9   HOUR_APPR_PROCESS_START      1670214 non-null  int64  
     10  FLAG_LAST_APPL_PER_CONTRACT  1670214 non-null  object 
     11  NFLAG_LAST_APPL_IN_DAY       1670214 non-null  int64  
     12  RATE_DOWN_PAYMENT            774370 non-null   float64
     13  RATE_INTEREST_PRIMARY        5951 non-null     float64
     14  RATE_INTEREST_PRIVILEGED     5951 non-null     float64
     15  NAME_CASH_LOAN_PURPOSE       1670214 non-null  object 
     16  NAME_CONTRACT_STATUS         1670214 non-null  object 
     17  DAYS_DECISION                1670214 non-null  int64  
     18  NAME_PAYMENT_TYPE            1670214 non-null  object 
     19  CODE_REJECT_REASON           1670214 non-null  object 
     20  NAME_TYPE_SUITE              849809 non-null   object 
     21  NAME_CLIENT_TYPE             1670214 non-null  object 
     22  NAME_GOODS_CATEGORY          1670214 non-null  object 
     23  NAME_PORTFOLIO               1670214 non-null  object 
     24  NAME_PRODUCT_TYPE            1670214 non-null  object 
     25  CHANNEL_TYPE                 1670214 non-null  object 
     26  SELLERPLACE_AREA             1670214 non-null  int64  
     27  NAME_SELLER_INDUSTRY         1670214 non-null  object 
     28  CNT_PAYMENT                  1297984 non-null  float64
     29  NAME_YIELD_GROUP             1670214 non-null  object 
     30  PRODUCT_COMBINATION          1669868 non-null  object 
     31  DAYS_FIRST_DRAWING           997149 non-null   float64
     32  DAYS_FIRST_DUE               997149 non-null   float64
     33  DAYS_LAST_DUE_1ST_VERSION    997149 non-null   float64
     34  DAYS_LAST_DUE                997149 non-null   float64
     35  DAYS_TERMINATION             997149 non-null   float64
     36  NFLAG_INSURED_ON_APPROVAL    997149 non-null   float64
    dtypes: float64(15), int64(6), object(16)
    memory usage: 471.5+ MB
    


```python
applicationdf.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SK_ID_CURR</th>
      <th>TARGET</th>
      <th>CNT_CHILDREN</th>
      <th>AMT_INCOME_TOTAL</th>
      <th>AMT_CREDIT</th>
      <th>AMT_ANNUITY</th>
      <th>AMT_GOODS_PRICE</th>
      <th>REGION_POPULATION_RELATIVE</th>
      <th>DAYS_BIRTH</th>
      <th>DAYS_EMPLOYED</th>
      <th>DAYS_REGISTRATION</th>
      <th>DAYS_ID_PUBLISH</th>
      <th>OWN_CAR_AGE</th>
      <th>FLAG_MOBIL</th>
      <th>FLAG_EMP_PHONE</th>
      <th>FLAG_WORK_PHONE</th>
      <th>FLAG_CONT_MOBILE</th>
      <th>FLAG_PHONE</th>
      <th>FLAG_EMAIL</th>
      <th>CNT_FAM_MEMBERS</th>
      <th>REGION_RATING_CLIENT</th>
      <th>REGION_RATING_CLIENT_W_CITY</th>
      <th>HOUR_APPR_PROCESS_START</th>
      <th>REG_REGION_NOT_LIVE_REGION</th>
      <th>REG_REGION_NOT_WORK_REGION</th>
      <th>LIVE_REGION_NOT_WORK_REGION</th>
      <th>REG_CITY_NOT_LIVE_CITY</th>
      <th>REG_CITY_NOT_WORK_CITY</th>
      <th>LIVE_CITY_NOT_WORK_CITY</th>
      <th>EXT_SOURCE_1</th>
      <th>EXT_SOURCE_2</th>
      <th>EXT_SOURCE_3</th>
      <th>APARTMENTS_AVG</th>
      <th>BASEMENTAREA_AVG</th>
      <th>YEARS_BEGINEXPLUATATION_AVG</th>
      <th>YEARS_BUILD_AVG</th>
      <th>COMMONAREA_AVG</th>
      <th>ELEVATORS_AVG</th>
      <th>ENTRANCES_AVG</th>
      <th>FLOORSMAX_AVG</th>
      <th>FLOORSMIN_AVG</th>
      <th>LANDAREA_AVG</th>
      <th>LIVINGAPARTMENTS_AVG</th>
      <th>LIVINGAREA_AVG</th>
      <th>NONLIVINGAPARTMENTS_AVG</th>
      <th>NONLIVINGAREA_AVG</th>
      <th>APARTMENTS_MODE</th>
      <th>BASEMENTAREA_MODE</th>
      <th>YEARS_BEGINEXPLUATATION_MODE</th>
      <th>YEARS_BUILD_MODE</th>
      <th>COMMONAREA_MODE</th>
      <th>ELEVATORS_MODE</th>
      <th>ENTRANCES_MODE</th>
      <th>FLOORSMAX_MODE</th>
      <th>FLOORSMIN_MODE</th>
      <th>LANDAREA_MODE</th>
      <th>LIVINGAPARTMENTS_MODE</th>
      <th>LIVINGAREA_MODE</th>
      <th>NONLIVINGAPARTMENTS_MODE</th>
      <th>NONLIVINGAREA_MODE</th>
      <th>APARTMENTS_MEDI</th>
      <th>BASEMENTAREA_MEDI</th>
      <th>YEARS_BEGINEXPLUATATION_MEDI</th>
      <th>YEARS_BUILD_MEDI</th>
      <th>COMMONAREA_MEDI</th>
      <th>ELEVATORS_MEDI</th>
      <th>ENTRANCES_MEDI</th>
      <th>FLOORSMAX_MEDI</th>
      <th>FLOORSMIN_MEDI</th>
      <th>LANDAREA_MEDI</th>
      <th>LIVINGAPARTMENTS_MEDI</th>
      <th>LIVINGAREA_MEDI</th>
      <th>NONLIVINGAPARTMENTS_MEDI</th>
      <th>NONLIVINGAREA_MEDI</th>
      <th>TOTALAREA_MODE</th>
      <th>OBS_30_CNT_SOCIAL_CIRCLE</th>
      <th>DEF_30_CNT_SOCIAL_CIRCLE</th>
      <th>OBS_60_CNT_SOCIAL_CIRCLE</th>
      <th>DEF_60_CNT_SOCIAL_CIRCLE</th>
      <th>DAYS_LAST_PHONE_CHANGE</th>
      <th>FLAG_DOCUMENT_2</th>
      <th>FLAG_DOCUMENT_3</th>
      <th>FLAG_DOCUMENT_4</th>
      <th>FLAG_DOCUMENT_5</th>
      <th>FLAG_DOCUMENT_6</th>
      <th>FLAG_DOCUMENT_7</th>
      <th>FLAG_DOCUMENT_8</th>
      <th>FLAG_DOCUMENT_9</th>
      <th>FLAG_DOCUMENT_10</th>
      <th>FLAG_DOCUMENT_11</th>
      <th>FLAG_DOCUMENT_12</th>
      <th>FLAG_DOCUMENT_13</th>
      <th>FLAG_DOCUMENT_14</th>
      <th>FLAG_DOCUMENT_15</th>
      <th>FLAG_DOCUMENT_16</th>
      <th>FLAG_DOCUMENT_17</th>
      <th>FLAG_DOCUMENT_18</th>
      <th>FLAG_DOCUMENT_19</th>
      <th>FLAG_DOCUMENT_20</th>
      <th>FLAG_DOCUMENT_21</th>
      <th>AMT_REQ_CREDIT_BUREAU_HOUR</th>
      <th>AMT_REQ_CREDIT_BUREAU_DAY</th>
      <th>AMT_REQ_CREDIT_BUREAU_WEEK</th>
      <th>AMT_REQ_CREDIT_BUREAU_MON</th>
      <th>AMT_REQ_CREDIT_BUREAU_QRT</th>
      <th>AMT_REQ_CREDIT_BUREAU_YEAR</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>3.075110e+05</td>
      <td>3.075110e+05</td>
      <td>307499.000000</td>
      <td>3.072330e+05</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>104582.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307509.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>134133.000000</td>
      <td>3.068510e+05</td>
      <td>246546.000000</td>
      <td>151450.00000</td>
      <td>127568.000000</td>
      <td>157504.000000</td>
      <td>103023.000000</td>
      <td>92646.000000</td>
      <td>143620.000000</td>
      <td>152683.000000</td>
      <td>154491.000000</td>
      <td>98869.000000</td>
      <td>124921.000000</td>
      <td>97312.000000</td>
      <td>153161.000000</td>
      <td>93997.000000</td>
      <td>137829.000000</td>
      <td>151450.000000</td>
      <td>127568.000000</td>
      <td>157504.000000</td>
      <td>103023.000000</td>
      <td>92646.000000</td>
      <td>143620.000000</td>
      <td>152683.000000</td>
      <td>154491.000000</td>
      <td>98869.000000</td>
      <td>124921.000000</td>
      <td>97312.000000</td>
      <td>153161.000000</td>
      <td>93997.000000</td>
      <td>137829.000000</td>
      <td>151450.000000</td>
      <td>127568.000000</td>
      <td>157504.000000</td>
      <td>103023.000000</td>
      <td>92646.000000</td>
      <td>143620.000000</td>
      <td>152683.000000</td>
      <td>154491.000000</td>
      <td>98869.000000</td>
      <td>124921.000000</td>
      <td>97312.000000</td>
      <td>153161.000000</td>
      <td>93997.000000</td>
      <td>137829.000000</td>
      <td>159080.000000</td>
      <td>306490.000000</td>
      <td>306490.000000</td>
      <td>306490.000000</td>
      <td>306490.000000</td>
      <td>307510.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.00000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>307511.000000</td>
      <td>265992.000000</td>
      <td>265992.000000</td>
      <td>265992.000000</td>
      <td>265992.000000</td>
      <td>265992.000000</td>
      <td>265992.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>278180.518577</td>
      <td>0.080729</td>
      <td>0.417052</td>
      <td>1.687979e+05</td>
      <td>5.990260e+05</td>
      <td>27108.573909</td>
      <td>5.383962e+05</td>
      <td>0.020868</td>
      <td>-16036.995067</td>
      <td>63815.045904</td>
      <td>-4986.120328</td>
      <td>-2994.202373</td>
      <td>12.061091</td>
      <td>0.999997</td>
      <td>0.819889</td>
      <td>0.199368</td>
      <td>0.998133</td>
      <td>0.281066</td>
      <td>0.056720</td>
      <td>2.152665</td>
      <td>2.052463</td>
      <td>2.031521</td>
      <td>12.063419</td>
      <td>0.015144</td>
      <td>0.050769</td>
      <td>0.040659</td>
      <td>0.078173</td>
      <td>0.230454</td>
      <td>0.179555</td>
      <td>0.502130</td>
      <td>5.143927e-01</td>
      <td>0.510853</td>
      <td>0.11744</td>
      <td>0.088442</td>
      <td>0.977735</td>
      <td>0.752471</td>
      <td>0.044621</td>
      <td>0.078942</td>
      <td>0.149725</td>
      <td>0.226282</td>
      <td>0.231894</td>
      <td>0.066333</td>
      <td>0.100775</td>
      <td>0.107399</td>
      <td>0.008809</td>
      <td>0.028358</td>
      <td>0.114231</td>
      <td>0.087543</td>
      <td>0.977065</td>
      <td>0.759637</td>
      <td>0.042553</td>
      <td>0.074490</td>
      <td>0.145193</td>
      <td>0.222315</td>
      <td>0.228058</td>
      <td>0.064958</td>
      <td>0.105645</td>
      <td>0.105975</td>
      <td>0.008076</td>
      <td>0.027022</td>
      <td>0.117850</td>
      <td>0.087955</td>
      <td>0.977752</td>
      <td>0.755746</td>
      <td>0.044595</td>
      <td>0.078078</td>
      <td>0.149213</td>
      <td>0.225897</td>
      <td>0.231625</td>
      <td>0.067169</td>
      <td>0.101954</td>
      <td>0.108607</td>
      <td>0.008651</td>
      <td>0.028236</td>
      <td>0.102547</td>
      <td>1.422245</td>
      <td>0.143421</td>
      <td>1.405292</td>
      <td>0.100049</td>
      <td>-962.858788</td>
      <td>0.000042</td>
      <td>0.710023</td>
      <td>0.000081</td>
      <td>0.015115</td>
      <td>0.088055</td>
      <td>0.000192</td>
      <td>0.081376</td>
      <td>0.003896</td>
      <td>0.000023</td>
      <td>0.003912</td>
      <td>0.000007</td>
      <td>0.003525</td>
      <td>0.002936</td>
      <td>0.00121</td>
      <td>0.009928</td>
      <td>0.000267</td>
      <td>0.008130</td>
      <td>0.000595</td>
      <td>0.000507</td>
      <td>0.000335</td>
      <td>0.006402</td>
      <td>0.007000</td>
      <td>0.034362</td>
      <td>0.267395</td>
      <td>0.265474</td>
      <td>1.899974</td>
    </tr>
    <tr>
      <th>std</th>
      <td>102790.175348</td>
      <td>0.272419</td>
      <td>0.722121</td>
      <td>2.371231e+05</td>
      <td>4.024908e+05</td>
      <td>14493.737315</td>
      <td>3.694465e+05</td>
      <td>0.013831</td>
      <td>4363.988632</td>
      <td>141275.766519</td>
      <td>3522.886321</td>
      <td>1509.450419</td>
      <td>11.944812</td>
      <td>0.001803</td>
      <td>0.384280</td>
      <td>0.399526</td>
      <td>0.043164</td>
      <td>0.449521</td>
      <td>0.231307</td>
      <td>0.910682</td>
      <td>0.509034</td>
      <td>0.502737</td>
      <td>3.265832</td>
      <td>0.122126</td>
      <td>0.219526</td>
      <td>0.197499</td>
      <td>0.268444</td>
      <td>0.421124</td>
      <td>0.383817</td>
      <td>0.211062</td>
      <td>1.910602e-01</td>
      <td>0.194844</td>
      <td>0.10824</td>
      <td>0.082438</td>
      <td>0.059223</td>
      <td>0.113280</td>
      <td>0.076036</td>
      <td>0.134576</td>
      <td>0.100049</td>
      <td>0.144641</td>
      <td>0.161380</td>
      <td>0.081184</td>
      <td>0.092576</td>
      <td>0.110565</td>
      <td>0.047732</td>
      <td>0.069523</td>
      <td>0.107936</td>
      <td>0.084307</td>
      <td>0.064575</td>
      <td>0.110111</td>
      <td>0.074445</td>
      <td>0.132256</td>
      <td>0.100977</td>
      <td>0.143709</td>
      <td>0.161160</td>
      <td>0.081750</td>
      <td>0.097880</td>
      <td>0.111845</td>
      <td>0.046276</td>
      <td>0.070254</td>
      <td>0.109076</td>
      <td>0.082179</td>
      <td>0.059897</td>
      <td>0.112066</td>
      <td>0.076144</td>
      <td>0.134467</td>
      <td>0.100368</td>
      <td>0.145067</td>
      <td>0.161934</td>
      <td>0.082167</td>
      <td>0.093642</td>
      <td>0.112260</td>
      <td>0.047415</td>
      <td>0.070166</td>
      <td>0.107462</td>
      <td>2.400989</td>
      <td>0.446698</td>
      <td>2.379803</td>
      <td>0.362291</td>
      <td>826.808487</td>
      <td>0.006502</td>
      <td>0.453752</td>
      <td>0.009016</td>
      <td>0.122010</td>
      <td>0.283376</td>
      <td>0.013850</td>
      <td>0.273412</td>
      <td>0.062295</td>
      <td>0.004771</td>
      <td>0.062424</td>
      <td>0.002550</td>
      <td>0.059268</td>
      <td>0.054110</td>
      <td>0.03476</td>
      <td>0.099144</td>
      <td>0.016327</td>
      <td>0.089798</td>
      <td>0.024387</td>
      <td>0.022518</td>
      <td>0.018299</td>
      <td>0.083849</td>
      <td>0.110757</td>
      <td>0.204685</td>
      <td>0.916002</td>
      <td>0.794056</td>
      <td>1.869295</td>
    </tr>
    <tr>
      <th>min</th>
      <td>100002.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>2.565000e+04</td>
      <td>4.500000e+04</td>
      <td>1615.500000</td>
      <td>4.050000e+04</td>
      <td>0.000290</td>
      <td>-25229.000000</td>
      <td>-17912.000000</td>
      <td>-24672.000000</td>
      <td>-7197.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.014568</td>
      <td>8.173617e-08</td>
      <td>0.000527</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-4292.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>189145.500000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.125000e+05</td>
      <td>2.700000e+05</td>
      <td>16524.000000</td>
      <td>2.385000e+05</td>
      <td>0.010006</td>
      <td>-19682.000000</td>
      <td>-2760.000000</td>
      <td>-7479.500000</td>
      <td>-4299.000000</td>
      <td>5.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>10.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.334007</td>
      <td>3.924574e-01</td>
      <td>0.370650</td>
      <td>0.05770</td>
      <td>0.044200</td>
      <td>0.976700</td>
      <td>0.687200</td>
      <td>0.007800</td>
      <td>0.000000</td>
      <td>0.069000</td>
      <td>0.166700</td>
      <td>0.083300</td>
      <td>0.018700</td>
      <td>0.050400</td>
      <td>0.045300</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.052500</td>
      <td>0.040700</td>
      <td>0.976700</td>
      <td>0.699400</td>
      <td>0.007200</td>
      <td>0.000000</td>
      <td>0.069000</td>
      <td>0.166700</td>
      <td>0.083300</td>
      <td>0.016600</td>
      <td>0.054200</td>
      <td>0.042700</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.058300</td>
      <td>0.043700</td>
      <td>0.976700</td>
      <td>0.691400</td>
      <td>0.007900</td>
      <td>0.000000</td>
      <td>0.069000</td>
      <td>0.166700</td>
      <td>0.083300</td>
      <td>0.018700</td>
      <td>0.051300</td>
      <td>0.045700</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.041200</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-1570.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>278202.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.471500e+05</td>
      <td>5.135310e+05</td>
      <td>24903.000000</td>
      <td>4.500000e+05</td>
      <td>0.018850</td>
      <td>-15750.000000</td>
      <td>-1213.000000</td>
      <td>-4504.000000</td>
      <td>-3254.000000</td>
      <td>9.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>12.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.505998</td>
      <td>5.659614e-01</td>
      <td>0.535276</td>
      <td>0.08760</td>
      <td>0.076300</td>
      <td>0.981600</td>
      <td>0.755200</td>
      <td>0.021100</td>
      <td>0.000000</td>
      <td>0.137900</td>
      <td>0.166700</td>
      <td>0.208300</td>
      <td>0.048100</td>
      <td>0.075600</td>
      <td>0.074500</td>
      <td>0.000000</td>
      <td>0.003600</td>
      <td>0.084000</td>
      <td>0.074600</td>
      <td>0.981600</td>
      <td>0.764800</td>
      <td>0.019000</td>
      <td>0.000000</td>
      <td>0.137900</td>
      <td>0.166700</td>
      <td>0.208300</td>
      <td>0.045800</td>
      <td>0.077100</td>
      <td>0.073100</td>
      <td>0.000000</td>
      <td>0.001100</td>
      <td>0.086400</td>
      <td>0.075800</td>
      <td>0.981600</td>
      <td>0.758500</td>
      <td>0.020800</td>
      <td>0.000000</td>
      <td>0.137900</td>
      <td>0.166700</td>
      <td>0.208300</td>
      <td>0.048700</td>
      <td>0.076100</td>
      <td>0.074900</td>
      <td>0.000000</td>
      <td>0.003100</td>
      <td>0.068800</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-757.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>367142.500000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>2.025000e+05</td>
      <td>8.086500e+05</td>
      <td>34596.000000</td>
      <td>6.795000e+05</td>
      <td>0.028663</td>
      <td>-12413.000000</td>
      <td>-289.000000</td>
      <td>-2010.000000</td>
      <td>-1720.000000</td>
      <td>15.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>14.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.675053</td>
      <td>6.636171e-01</td>
      <td>0.669057</td>
      <td>0.14850</td>
      <td>0.112200</td>
      <td>0.986600</td>
      <td>0.823200</td>
      <td>0.051500</td>
      <td>0.120000</td>
      <td>0.206900</td>
      <td>0.333300</td>
      <td>0.375000</td>
      <td>0.085600</td>
      <td>0.121000</td>
      <td>0.129900</td>
      <td>0.003900</td>
      <td>0.027700</td>
      <td>0.143900</td>
      <td>0.112400</td>
      <td>0.986600</td>
      <td>0.823600</td>
      <td>0.049000</td>
      <td>0.120800</td>
      <td>0.206900</td>
      <td>0.333300</td>
      <td>0.375000</td>
      <td>0.084100</td>
      <td>0.131300</td>
      <td>0.125200</td>
      <td>0.003900</td>
      <td>0.023100</td>
      <td>0.148900</td>
      <td>0.111600</td>
      <td>0.986600</td>
      <td>0.825600</td>
      <td>0.051300</td>
      <td>0.120000</td>
      <td>0.206900</td>
      <td>0.333300</td>
      <td>0.375000</td>
      <td>0.086800</td>
      <td>0.123100</td>
      <td>0.130300</td>
      <td>0.003900</td>
      <td>0.026600</td>
      <td>0.127600</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>-274.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>456255.000000</td>
      <td>1.000000</td>
      <td>19.000000</td>
      <td>1.170000e+08</td>
      <td>4.050000e+06</td>
      <td>258025.500000</td>
      <td>4.050000e+06</td>
      <td>0.072508</td>
      <td>-7489.000000</td>
      <td>365243.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>91.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>20.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
      <td>23.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.962693</td>
      <td>8.549997e-01</td>
      <td>0.896010</td>
      <td>1.00000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>348.000000</td>
      <td>34.000000</td>
      <td>344.000000</td>
      <td>24.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.00000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>4.000000</td>
      <td>9.000000</td>
      <td>8.000000</td>
      <td>27.000000</td>
      <td>261.000000</td>
      <td>25.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
previousdf.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SK_ID_PREV</th>
      <th>SK_ID_CURR</th>
      <th>AMT_ANNUITY</th>
      <th>AMT_APPLICATION</th>
      <th>AMT_CREDIT</th>
      <th>AMT_DOWN_PAYMENT</th>
      <th>AMT_GOODS_PRICE</th>
      <th>HOUR_APPR_PROCESS_START</th>
      <th>NFLAG_LAST_APPL_IN_DAY</th>
      <th>RATE_DOWN_PAYMENT</th>
      <th>RATE_INTEREST_PRIMARY</th>
      <th>RATE_INTEREST_PRIVILEGED</th>
      <th>DAYS_DECISION</th>
      <th>SELLERPLACE_AREA</th>
      <th>CNT_PAYMENT</th>
      <th>DAYS_FIRST_DRAWING</th>
      <th>DAYS_FIRST_DUE</th>
      <th>DAYS_LAST_DUE_1ST_VERSION</th>
      <th>DAYS_LAST_DUE</th>
      <th>DAYS_TERMINATION</th>
      <th>NFLAG_INSURED_ON_APPROVAL</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1.670214e+06</td>
      <td>1.670214e+06</td>
      <td>1.297979e+06</td>
      <td>1.670214e+06</td>
      <td>1.670213e+06</td>
      <td>7.743700e+05</td>
      <td>1.284699e+06</td>
      <td>1.670214e+06</td>
      <td>1.670214e+06</td>
      <td>774370.000000</td>
      <td>5951.000000</td>
      <td>5951.000000</td>
      <td>1.670214e+06</td>
      <td>1.670214e+06</td>
      <td>1.297984e+06</td>
      <td>997149.000000</td>
      <td>997149.000000</td>
      <td>997149.000000</td>
      <td>997149.000000</td>
      <td>997149.000000</td>
      <td>997149.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1.923089e+06</td>
      <td>2.783572e+05</td>
      <td>1.595512e+04</td>
      <td>1.752339e+05</td>
      <td>1.961140e+05</td>
      <td>6.697402e+03</td>
      <td>2.278473e+05</td>
      <td>1.248418e+01</td>
      <td>9.964675e-01</td>
      <td>0.079637</td>
      <td>0.188357</td>
      <td>0.773503</td>
      <td>-8.806797e+02</td>
      <td>3.139511e+02</td>
      <td>1.605408e+01</td>
      <td>342209.855039</td>
      <td>13826.269337</td>
      <td>33767.774054</td>
      <td>76582.403064</td>
      <td>81992.343838</td>
      <td>0.332570</td>
    </tr>
    <tr>
      <th>std</th>
      <td>5.325980e+05</td>
      <td>1.028148e+05</td>
      <td>1.478214e+04</td>
      <td>2.927798e+05</td>
      <td>3.185746e+05</td>
      <td>2.092150e+04</td>
      <td>3.153966e+05</td>
      <td>3.334028e+00</td>
      <td>5.932963e-02</td>
      <td>0.107823</td>
      <td>0.087671</td>
      <td>0.100879</td>
      <td>7.790997e+02</td>
      <td>7.127443e+03</td>
      <td>1.456729e+01</td>
      <td>88916.115834</td>
      <td>72444.869708</td>
      <td>106857.034789</td>
      <td>149647.415123</td>
      <td>153303.516729</td>
      <td>0.471134</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000001e+06</td>
      <td>1.000010e+05</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>-9.000000e-01</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>-0.000015</td>
      <td>0.034781</td>
      <td>0.373150</td>
      <td>-2.922000e+03</td>
      <td>-1.000000e+00</td>
      <td>0.000000e+00</td>
      <td>-2922.000000</td>
      <td>-2892.000000</td>
      <td>-2801.000000</td>
      <td>-2889.000000</td>
      <td>-2874.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1.461857e+06</td>
      <td>1.893290e+05</td>
      <td>6.321780e+03</td>
      <td>1.872000e+04</td>
      <td>2.416050e+04</td>
      <td>0.000000e+00</td>
      <td>5.084100e+04</td>
      <td>1.000000e+01</td>
      <td>1.000000e+00</td>
      <td>0.000000</td>
      <td>0.160716</td>
      <td>0.715645</td>
      <td>-1.300000e+03</td>
      <td>-1.000000e+00</td>
      <td>6.000000e+00</td>
      <td>365243.000000</td>
      <td>-1628.000000</td>
      <td>-1242.000000</td>
      <td>-1314.000000</td>
      <td>-1270.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1.923110e+06</td>
      <td>2.787145e+05</td>
      <td>1.125000e+04</td>
      <td>7.104600e+04</td>
      <td>8.054100e+04</td>
      <td>1.638000e+03</td>
      <td>1.123200e+05</td>
      <td>1.200000e+01</td>
      <td>1.000000e+00</td>
      <td>0.051605</td>
      <td>0.189122</td>
      <td>0.835095</td>
      <td>-5.810000e+02</td>
      <td>3.000000e+00</td>
      <td>1.200000e+01</td>
      <td>365243.000000</td>
      <td>-831.000000</td>
      <td>-361.000000</td>
      <td>-537.000000</td>
      <td>-499.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2.384280e+06</td>
      <td>3.675140e+05</td>
      <td>2.065842e+04</td>
      <td>1.803600e+05</td>
      <td>2.164185e+05</td>
      <td>7.740000e+03</td>
      <td>2.340000e+05</td>
      <td>1.500000e+01</td>
      <td>1.000000e+00</td>
      <td>0.108909</td>
      <td>0.193330</td>
      <td>0.852537</td>
      <td>-2.800000e+02</td>
      <td>8.200000e+01</td>
      <td>2.400000e+01</td>
      <td>365243.000000</td>
      <td>-411.000000</td>
      <td>129.000000</td>
      <td>-74.000000</td>
      <td>-44.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2.845382e+06</td>
      <td>4.562550e+05</td>
      <td>4.180581e+05</td>
      <td>6.905160e+06</td>
      <td>6.905160e+06</td>
      <td>3.060045e+06</td>
      <td>6.905160e+06</td>
      <td>2.300000e+01</td>
      <td>1.000000e+00</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>-1.000000e+00</td>
      <td>4.000000e+06</td>
      <td>8.400000e+01</td>
      <td>365243.000000</td>
      <td>365243.000000</td>
      <td>365243.000000</td>
      <td>365243.000000</td>
      <td>365243.000000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
conda install -c conda-forge/label/gcc7 missingno
```

    Collecting package metadata (current_repodata.json): ...working... done
    Solving environment: ...working... done
    
    # All requested packages already installed.
    
    
    Note: you may need to restart the kernel to use updated packages.
    


```python
import missingno as mn
mn.matrix(applicationdf)
```




    <AxesSubplot:>




    
![png](output_14_1.png)
    



```python
round(applicationdf.isnull().sum() / applicationdf.shape[0] * 100.00,2)
```




    SK_ID_CURR                       0.00
    TARGET                           0.00
    NAME_CONTRACT_TYPE               0.00
    CODE_GENDER                      0.00
    FLAG_OWN_CAR                     0.00
    FLAG_OWN_REALTY                  0.00
    CNT_CHILDREN                     0.00
    AMT_INCOME_TOTAL                 0.00
    AMT_CREDIT                       0.00
    AMT_ANNUITY                      0.00
    AMT_GOODS_PRICE                  0.09
    NAME_TYPE_SUITE                  0.42
    NAME_INCOME_TYPE                 0.00
    NAME_EDUCATION_TYPE              0.00
    NAME_FAMILY_STATUS               0.00
    NAME_HOUSING_TYPE                0.00
    REGION_POPULATION_RELATIVE       0.00
    DAYS_BIRTH                       0.00
    DAYS_EMPLOYED                    0.00
    DAYS_REGISTRATION                0.00
    DAYS_ID_PUBLISH                  0.00
    OWN_CAR_AGE                     65.99
    FLAG_MOBIL                       0.00
    FLAG_EMP_PHONE                   0.00
    FLAG_WORK_PHONE                  0.00
    FLAG_CONT_MOBILE                 0.00
    FLAG_PHONE                       0.00
    FLAG_EMAIL                       0.00
    OCCUPATION_TYPE                 31.35
    CNT_FAM_MEMBERS                  0.00
    REGION_RATING_CLIENT             0.00
    REGION_RATING_CLIENT_W_CITY      0.00
    WEEKDAY_APPR_PROCESS_START       0.00
    HOUR_APPR_PROCESS_START          0.00
    REG_REGION_NOT_LIVE_REGION       0.00
    REG_REGION_NOT_WORK_REGION       0.00
    LIVE_REGION_NOT_WORK_REGION      0.00
    REG_CITY_NOT_LIVE_CITY           0.00
    REG_CITY_NOT_WORK_CITY           0.00
    LIVE_CITY_NOT_WORK_CITY          0.00
    ORGANIZATION_TYPE                0.00
    EXT_SOURCE_1                    56.38
    EXT_SOURCE_2                     0.21
    EXT_SOURCE_3                    19.83
    APARTMENTS_AVG                  50.75
    BASEMENTAREA_AVG                58.52
    YEARS_BEGINEXPLUATATION_AVG     48.78
    YEARS_BUILD_AVG                 66.50
    COMMONAREA_AVG                  69.87
    ELEVATORS_AVG                   53.30
    ENTRANCES_AVG                   50.35
    FLOORSMAX_AVG                   49.76
    FLOORSMIN_AVG                   67.85
    LANDAREA_AVG                    59.38
    LIVINGAPARTMENTS_AVG            68.35
    LIVINGAREA_AVG                  50.19
    NONLIVINGAPARTMENTS_AVG         69.43
    NONLIVINGAREA_AVG               55.18
    APARTMENTS_MODE                 50.75
    BASEMENTAREA_MODE               58.52
    YEARS_BEGINEXPLUATATION_MODE    48.78
    YEARS_BUILD_MODE                66.50
    COMMONAREA_MODE                 69.87
    ELEVATORS_MODE                  53.30
    ENTRANCES_MODE                  50.35
    FLOORSMAX_MODE                  49.76
    FLOORSMIN_MODE                  67.85
    LANDAREA_MODE                   59.38
    LIVINGAPARTMENTS_MODE           68.35
    LIVINGAREA_MODE                 50.19
    NONLIVINGAPARTMENTS_MODE        69.43
    NONLIVINGAREA_MODE              55.18
    APARTMENTS_MEDI                 50.75
    BASEMENTAREA_MEDI               58.52
    YEARS_BEGINEXPLUATATION_MEDI    48.78
    YEARS_BUILD_MEDI                66.50
    COMMONAREA_MEDI                 69.87
    ELEVATORS_MEDI                  53.30
    ENTRANCES_MEDI                  50.35
    FLOORSMAX_MEDI                  49.76
    FLOORSMIN_MEDI                  67.85
    LANDAREA_MEDI                   59.38
    LIVINGAPARTMENTS_MEDI           68.35
    LIVINGAREA_MEDI                 50.19
    NONLIVINGAPARTMENTS_MEDI        69.43
    NONLIVINGAREA_MEDI              55.18
    FONDKAPREMONT_MODE              68.39
    HOUSETYPE_MODE                  50.18
    TOTALAREA_MODE                  48.27
    WALLSMATERIAL_MODE              50.84
    EMERGENCYSTATE_MODE             47.40
    OBS_30_CNT_SOCIAL_CIRCLE         0.33
    DEF_30_CNT_SOCIAL_CIRCLE         0.33
    OBS_60_CNT_SOCIAL_CIRCLE         0.33
    DEF_60_CNT_SOCIAL_CIRCLE         0.33
    DAYS_LAST_PHONE_CHANGE           0.00
    FLAG_DOCUMENT_2                  0.00
    FLAG_DOCUMENT_3                  0.00
    FLAG_DOCUMENT_4                  0.00
    FLAG_DOCUMENT_5                  0.00
    FLAG_DOCUMENT_6                  0.00
    FLAG_DOCUMENT_7                  0.00
    FLAG_DOCUMENT_8                  0.00
    FLAG_DOCUMENT_9                  0.00
    FLAG_DOCUMENT_10                 0.00
    FLAG_DOCUMENT_11                 0.00
    FLAG_DOCUMENT_12                 0.00
    FLAG_DOCUMENT_13                 0.00
    FLAG_DOCUMENT_14                 0.00
    FLAG_DOCUMENT_15                 0.00
    FLAG_DOCUMENT_16                 0.00
    FLAG_DOCUMENT_17                 0.00
    FLAG_DOCUMENT_18                 0.00
    FLAG_DOCUMENT_19                 0.00
    FLAG_DOCUMENT_20                 0.00
    FLAG_DOCUMENT_21                 0.00
    AMT_REQ_CREDIT_BUREAU_HOUR      13.50
    AMT_REQ_CREDIT_BUREAU_DAY       13.50
    AMT_REQ_CREDIT_BUREAU_WEEK      13.50
    AMT_REQ_CREDIT_BUREAU_MON       13.50
    AMT_REQ_CREDIT_BUREAU_QRT       13.50
    AMT_REQ_CREDIT_BUREAU_YEAR      13.50
    dtype: float64




```python
null_applicationdf = pd.DataFrame((applicationdf.isnull().sum())*100/applicationdf.shape[0]).reset_index()
null_applicationdf.columns = ['Column Name', 'Null Values Percentage']
fig = plt.figure(figsize=(18,6))
ax = sns.pointplot(x="Column Name",y="Null Values Percentage",data=null_applicationdf,color='red')
plt.xticks(rotation =90,fontsize =7)
ax.axhline(40, ls='--',color='blue')
plt.title("Percentage of Missing values in application data")
plt.ylabel("Null Values %")
plt.xlabel("COLUMNS")
plt.show()
```


    
![png](output_16_0.png)
    



```python
nullcol_40_application = null_applicationdf[null_applicationdf["Null Values Percentage"]>=40]
nullcol_40_application
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column Name</th>
      <th>Null Values Percentage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>21</th>
      <td>OWN_CAR_AGE</td>
      <td>65.990810</td>
    </tr>
    <tr>
      <th>41</th>
      <td>EXT_SOURCE_1</td>
      <td>56.381073</td>
    </tr>
    <tr>
      <th>44</th>
      <td>APARTMENTS_AVG</td>
      <td>50.749729</td>
    </tr>
    <tr>
      <th>45</th>
      <td>BASEMENTAREA_AVG</td>
      <td>58.515956</td>
    </tr>
    <tr>
      <th>46</th>
      <td>YEARS_BEGINEXPLUATATION_AVG</td>
      <td>48.781019</td>
    </tr>
    <tr>
      <th>47</th>
      <td>YEARS_BUILD_AVG</td>
      <td>66.497784</td>
    </tr>
    <tr>
      <th>48</th>
      <td>COMMONAREA_AVG</td>
      <td>69.872297</td>
    </tr>
    <tr>
      <th>49</th>
      <td>ELEVATORS_AVG</td>
      <td>53.295980</td>
    </tr>
    <tr>
      <th>50</th>
      <td>ENTRANCES_AVG</td>
      <td>50.348768</td>
    </tr>
    <tr>
      <th>51</th>
      <td>FLOORSMAX_AVG</td>
      <td>49.760822</td>
    </tr>
    <tr>
      <th>52</th>
      <td>FLOORSMIN_AVG</td>
      <td>67.848630</td>
    </tr>
    <tr>
      <th>53</th>
      <td>LANDAREA_AVG</td>
      <td>59.376738</td>
    </tr>
    <tr>
      <th>54</th>
      <td>LIVINGAPARTMENTS_AVG</td>
      <td>68.354953</td>
    </tr>
    <tr>
      <th>55</th>
      <td>LIVINGAREA_AVG</td>
      <td>50.193326</td>
    </tr>
    <tr>
      <th>56</th>
      <td>NONLIVINGAPARTMENTS_AVG</td>
      <td>69.432963</td>
    </tr>
    <tr>
      <th>57</th>
      <td>NONLIVINGAREA_AVG</td>
      <td>55.179164</td>
    </tr>
    <tr>
      <th>58</th>
      <td>APARTMENTS_MODE</td>
      <td>50.749729</td>
    </tr>
    <tr>
      <th>59</th>
      <td>BASEMENTAREA_MODE</td>
      <td>58.515956</td>
    </tr>
    <tr>
      <th>60</th>
      <td>YEARS_BEGINEXPLUATATION_MODE</td>
      <td>48.781019</td>
    </tr>
    <tr>
      <th>61</th>
      <td>YEARS_BUILD_MODE</td>
      <td>66.497784</td>
    </tr>
    <tr>
      <th>62</th>
      <td>COMMONAREA_MODE</td>
      <td>69.872297</td>
    </tr>
    <tr>
      <th>63</th>
      <td>ELEVATORS_MODE</td>
      <td>53.295980</td>
    </tr>
    <tr>
      <th>64</th>
      <td>ENTRANCES_MODE</td>
      <td>50.348768</td>
    </tr>
    <tr>
      <th>65</th>
      <td>FLOORSMAX_MODE</td>
      <td>49.760822</td>
    </tr>
    <tr>
      <th>66</th>
      <td>FLOORSMIN_MODE</td>
      <td>67.848630</td>
    </tr>
    <tr>
      <th>67</th>
      <td>LANDAREA_MODE</td>
      <td>59.376738</td>
    </tr>
    <tr>
      <th>68</th>
      <td>LIVINGAPARTMENTS_MODE</td>
      <td>68.354953</td>
    </tr>
    <tr>
      <th>69</th>
      <td>LIVINGAREA_MODE</td>
      <td>50.193326</td>
    </tr>
    <tr>
      <th>70</th>
      <td>NONLIVINGAPARTMENTS_MODE</td>
      <td>69.432963</td>
    </tr>
    <tr>
      <th>71</th>
      <td>NONLIVINGAREA_MODE</td>
      <td>55.179164</td>
    </tr>
    <tr>
      <th>72</th>
      <td>APARTMENTS_MEDI</td>
      <td>50.749729</td>
    </tr>
    <tr>
      <th>73</th>
      <td>BASEMENTAREA_MEDI</td>
      <td>58.515956</td>
    </tr>
    <tr>
      <th>74</th>
      <td>YEARS_BEGINEXPLUATATION_MEDI</td>
      <td>48.781019</td>
    </tr>
    <tr>
      <th>75</th>
      <td>YEARS_BUILD_MEDI</td>
      <td>66.497784</td>
    </tr>
    <tr>
      <th>76</th>
      <td>COMMONAREA_MEDI</td>
      <td>69.872297</td>
    </tr>
    <tr>
      <th>77</th>
      <td>ELEVATORS_MEDI</td>
      <td>53.295980</td>
    </tr>
    <tr>
      <th>78</th>
      <td>ENTRANCES_MEDI</td>
      <td>50.348768</td>
    </tr>
    <tr>
      <th>79</th>
      <td>FLOORSMAX_MEDI</td>
      <td>49.760822</td>
    </tr>
    <tr>
      <th>80</th>
      <td>FLOORSMIN_MEDI</td>
      <td>67.848630</td>
    </tr>
    <tr>
      <th>81</th>
      <td>LANDAREA_MEDI</td>
      <td>59.376738</td>
    </tr>
    <tr>
      <th>82</th>
      <td>LIVINGAPARTMENTS_MEDI</td>
      <td>68.354953</td>
    </tr>
    <tr>
      <th>83</th>
      <td>LIVINGAREA_MEDI</td>
      <td>50.193326</td>
    </tr>
    <tr>
      <th>84</th>
      <td>NONLIVINGAPARTMENTS_MEDI</td>
      <td>69.432963</td>
    </tr>
    <tr>
      <th>85</th>
      <td>NONLIVINGAREA_MEDI</td>
      <td>55.179164</td>
    </tr>
    <tr>
      <th>86</th>
      <td>FONDKAPREMONT_MODE</td>
      <td>68.386172</td>
    </tr>
    <tr>
      <th>87</th>
      <td>HOUSETYPE_MODE</td>
      <td>50.176091</td>
    </tr>
    <tr>
      <th>88</th>
      <td>TOTALAREA_MODE</td>
      <td>48.268517</td>
    </tr>
    <tr>
      <th>89</th>
      <td>WALLSMATERIAL_MODE</td>
      <td>50.840783</td>
    </tr>
    <tr>
      <th>90</th>
      <td>EMERGENCYSTATE_MODE</td>
      <td>47.398304</td>
    </tr>
  </tbody>
</table>
</div>




```python
len(nullcol_40_application)
```




    49




```python
mn.matrix(previousdf)
```




    <AxesSubplot:>




    
![png](output_19_1.png)
    



```python
round(previousdf.isnull().sum() / previousdf.shape[0] * 100.00,2)
```




    SK_ID_PREV                      0.00
    SK_ID_CURR                      0.00
    NAME_CONTRACT_TYPE              0.00
    AMT_ANNUITY                    22.29
    AMT_APPLICATION                 0.00
    AMT_CREDIT                      0.00
    AMT_DOWN_PAYMENT               53.64
    AMT_GOODS_PRICE                23.08
    WEEKDAY_APPR_PROCESS_START      0.00
    HOUR_APPR_PROCESS_START         0.00
    FLAG_LAST_APPL_PER_CONTRACT     0.00
    NFLAG_LAST_APPL_IN_DAY          0.00
    RATE_DOWN_PAYMENT              53.64
    RATE_INTEREST_PRIMARY          99.64
    RATE_INTEREST_PRIVILEGED       99.64
    NAME_CASH_LOAN_PURPOSE          0.00
    NAME_CONTRACT_STATUS            0.00
    DAYS_DECISION                   0.00
    NAME_PAYMENT_TYPE               0.00
    CODE_REJECT_REASON              0.00
    NAME_TYPE_SUITE                49.12
    NAME_CLIENT_TYPE                0.00
    NAME_GOODS_CATEGORY             0.00
    NAME_PORTFOLIO                  0.00
    NAME_PRODUCT_TYPE               0.00
    CHANNEL_TYPE                    0.00
    SELLERPLACE_AREA                0.00
    NAME_SELLER_INDUSTRY            0.00
    CNT_PAYMENT                    22.29
    NAME_YIELD_GROUP                0.00
    PRODUCT_COMBINATION             0.02
    DAYS_FIRST_DRAWING             40.30
    DAYS_FIRST_DUE                 40.30
    DAYS_LAST_DUE_1ST_VERSION      40.30
    DAYS_LAST_DUE                  40.30
    DAYS_TERMINATION               40.30
    NFLAG_INSURED_ON_APPROVAL      40.30
    dtype: float64




```python
null_previousdf = pd.DataFrame((previousdf.isnull().sum())*100/previousdf.shape[0]).reset_index()
null_previousdf.columns = ['Column Name', 'Null Values Percentage']
fig = plt.figure(figsize=(18,6))
ax = sns.pointplot(x="Column Name",y="Null Values Percentage",data=null_previousdf,color ='blue')
plt.xticks(rotation =90,fontsize =7)
ax.axhline(40, ls='--',color='red')
plt.title("Percentage of Missing values in previousdf data")
plt.ylabel("Null Values PERCENTAGE")
plt.xlabel("COLUMNS")
plt.show()
```


    
![png](output_21_0.png)
    



```python
nullcol_40_previous = null_previousdf[null_previousdf["Null Values Percentage"]>=40]
nullcol_40_previous
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Column Name</th>
      <th>Null Values Percentage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>6</th>
      <td>AMT_DOWN_PAYMENT</td>
      <td>53.636480</td>
    </tr>
    <tr>
      <th>12</th>
      <td>RATE_DOWN_PAYMENT</td>
      <td>53.636480</td>
    </tr>
    <tr>
      <th>13</th>
      <td>RATE_INTEREST_PRIMARY</td>
      <td>99.643698</td>
    </tr>
    <tr>
      <th>14</th>
      <td>RATE_INTEREST_PRIVILEGED</td>
      <td>99.643698</td>
    </tr>
    <tr>
      <th>20</th>
      <td>NAME_TYPE_SUITE</td>
      <td>49.119754</td>
    </tr>
    <tr>
      <th>31</th>
      <td>DAYS_FIRST_DRAWING</td>
      <td>40.298129</td>
    </tr>
    <tr>
      <th>32</th>
      <td>DAYS_FIRST_DUE</td>
      <td>40.298129</td>
    </tr>
    <tr>
      <th>33</th>
      <td>DAYS_LAST_DUE_1ST_VERSION</td>
      <td>40.298129</td>
    </tr>
    <tr>
      <th>34</th>
      <td>DAYS_LAST_DUE</td>
      <td>40.298129</td>
    </tr>
    <tr>
      <th>35</th>
      <td>DAYS_TERMINATION</td>
      <td>40.298129</td>
    </tr>
    <tr>
      <th>36</th>
      <td>NFLAG_INSURED_ON_APPROVAL</td>
      <td>40.298129</td>
    </tr>
  </tbody>
</table>
</div>




```python
len(nullcol_40_previous)
```




    11




```python
Source = applicationdf[["EXT_SOURCE_1","EXT_SOURCE_2","EXT_SOURCE_3","TARGET"]]
source_corr = Source.corr()
ax = sns.heatmap(source_corr,
            xticklabels=source_corr.columns,
            yticklabels=source_corr.columns,
            annot = True,
            cmap ="RdYlGn")
```


    
![png](output_24_0.png)
    



```python
Unwanted_application = nullcol_40_application["Column Name"].tolist()+ ['EXT_SOURCE_2','EXT_SOURCE_3']
len(Unwanted_application)

```




    51




```python
col_Doc = [ 'FLAG_DOCUMENT_2', 'FLAG_DOCUMENT_3','FLAG_DOCUMENT_4', 'FLAG_DOCUMENT_5', 'FLAG_DOCUMENT_6','FLAG_DOCUMENT_7', 
           'FLAG_DOCUMENT_8', 'FLAG_DOCUMENT_9','FLAG_DOCUMENT_10', 'FLAG_DOCUMENT_11', 'FLAG_DOCUMENT_12','FLAG_DOCUMENT_13',
           'FLAG_DOCUMENT_14', 'FLAG_DOCUMENT_15','FLAG_DOCUMENT_16', 'FLAG_DOCUMENT_17', 'FLAG_DOCUMENT_18',
           'FLAG_DOCUMENT_19', 'FLAG_DOCUMENT_20', 'FLAG_DOCUMENT_21']
df_flag = applicationdf[col_Doc+["TARGET"]]

length = len(col_Doc)

df_flag["TARGET"] = df_flag["TARGET"].replace({1:"Defaulter",0:"Repayer"})

fig = plt.figure(figsize=(21,24))

for i,j in itertools.zip_longest(col_Doc,range(length)):
    plt.subplot(5,4,j+1)
    ax = sns.countplot(df_flag[i],hue=df_flag["TARGET"],palette=["r","g"])
    plt.yticks(fontsize=8)
    plt.xlabel("")
    plt.ylabel("")
    plt.title(i)
```


    
![png](output_26_0.png)
    



```python
col_Doc.remove('FLAG_DOCUMENT_3') 
Unwanted_application = Unwanted_application + col_Doc
len(Unwanted_application)
```




    70




```python
contact_col = ['FLAG_MOBIL', 'FLAG_EMP_PHONE', 'FLAG_WORK_PHONE', 'FLAG_CONT_MOBILE',
       'FLAG_PHONE', 'FLAG_EMAIL','TARGET']
Contact_corr = applicationdf[contact_col].corr()
fig = plt.figure(figsize=(8,8))
ax = sns.heatmap(Contact_corr,
            xticklabels=Contact_corr.columns,
            yticklabels=Contact_corr.columns,
            annot = True,
            cmap ="RdYlGn",
            linewidth=1)
```


    
![png](output_28_0.png)
    



```python
contact_col.remove('TARGET') 
Unwanted_application = Unwanted_application + contact_col
len(Unwanted_application)
```




    76




```python
applicationdf.drop(labels=Unwanted_application,axis=1,inplace=True)
```


```python
applicationdf.shape
```




    (307511, 46)




```python
applicationdf.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 307511 entries, 0 to 307510
    Data columns (total 46 columns):
     #   Column                       Non-Null Count   Dtype  
    ---  ------                       --------------   -----  
     0   SK_ID_CURR                   307511 non-null  int64  
     1   TARGET                       307511 non-null  int64  
     2   NAME_CONTRACT_TYPE           307511 non-null  object 
     3   CODE_GENDER                  307511 non-null  object 
     4   FLAG_OWN_CAR                 307511 non-null  object 
     5   FLAG_OWN_REALTY              307511 non-null  object 
     6   CNT_CHILDREN                 307511 non-null  int64  
     7   AMT_INCOME_TOTAL             307511 non-null  float64
     8   AMT_CREDIT                   307511 non-null  float64
     9   AMT_ANNUITY                  307499 non-null  float64
     10  AMT_GOODS_PRICE              307233 non-null  float64
     11  NAME_TYPE_SUITE              306219 non-null  object 
     12  NAME_INCOME_TYPE             307511 non-null  object 
     13  NAME_EDUCATION_TYPE          307511 non-null  object 
     14  NAME_FAMILY_STATUS           307511 non-null  object 
     15  NAME_HOUSING_TYPE            307511 non-null  object 
     16  REGION_POPULATION_RELATIVE   307511 non-null  float64
     17  DAYS_BIRTH                   307511 non-null  int64  
     18  DAYS_EMPLOYED                307511 non-null  int64  
     19  DAYS_REGISTRATION            307511 non-null  float64
     20  DAYS_ID_PUBLISH              307511 non-null  int64  
     21  OCCUPATION_TYPE              211120 non-null  object 
     22  CNT_FAM_MEMBERS              307509 non-null  float64
     23  REGION_RATING_CLIENT         307511 non-null  int64  
     24  REGION_RATING_CLIENT_W_CITY  307511 non-null  int64  
     25  WEEKDAY_APPR_PROCESS_START   307511 non-null  object 
     26  HOUR_APPR_PROCESS_START      307511 non-null  int64  
     27  REG_REGION_NOT_LIVE_REGION   307511 non-null  int64  
     28  REG_REGION_NOT_WORK_REGION   307511 non-null  int64  
     29  LIVE_REGION_NOT_WORK_REGION  307511 non-null  int64  
     30  REG_CITY_NOT_LIVE_CITY       307511 non-null  int64  
     31  REG_CITY_NOT_WORK_CITY       307511 non-null  int64  
     32  LIVE_CITY_NOT_WORK_CITY      307511 non-null  int64  
     33  ORGANIZATION_TYPE            307511 non-null  object 
     34  OBS_30_CNT_SOCIAL_CIRCLE     306490 non-null  float64
     35  DEF_30_CNT_SOCIAL_CIRCLE     306490 non-null  float64
     36  OBS_60_CNT_SOCIAL_CIRCLE     306490 non-null  float64
     37  DEF_60_CNT_SOCIAL_CIRCLE     306490 non-null  float64
     38  DAYS_LAST_PHONE_CHANGE       307510 non-null  float64
     39  FLAG_DOCUMENT_3              307511 non-null  int64  
     40  AMT_REQ_CREDIT_BUREAU_HOUR   265992 non-null  float64
     41  AMT_REQ_CREDIT_BUREAU_DAY    265992 non-null  float64
     42  AMT_REQ_CREDIT_BUREAU_WEEK   265992 non-null  float64
     43  AMT_REQ_CREDIT_BUREAU_MON    265992 non-null  float64
     44  AMT_REQ_CREDIT_BUREAU_QRT    265992 non-null  float64
     45  AMT_REQ_CREDIT_BUREAU_YEAR   265992 non-null  float64
    dtypes: float64(18), int64(16), object(12)
    memory usage: 107.9+ MB
    


```python
Unwanted_previous = nullcol_40_previous["Column Name"].tolist()
Unwanted_previous
```




    ['AMT_DOWN_PAYMENT',
     'RATE_DOWN_PAYMENT',
     'RATE_INTEREST_PRIMARY',
     'RATE_INTEREST_PRIVILEGED',
     'NAME_TYPE_SUITE',
     'DAYS_FIRST_DRAWING',
     'DAYS_FIRST_DUE',
     'DAYS_LAST_DUE_1ST_VERSION',
     'DAYS_LAST_DUE',
     'DAYS_TERMINATION',
     'NFLAG_INSURED_ON_APPROVAL']




```python
Unnecessary_previous = ['WEEKDAY_APPR_PROCESS_START','HOUR_APPR_PROCESS_START',
                        'FLAG_LAST_APPL_PER_CONTRACT','NFLAG_LAST_APPL_IN_DAY']
```


```python
Unwanted_previous = Unwanted_previous + Unnecessary_previous
len(Unwanted_previous)
```




    15




```python
previousdf.drop(labels=Unwanted_previous,axis=1,inplace=True)
```


```python
previousdf.shape
```




    (1670214, 22)




```python
previousdf.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1670214 entries, 0 to 1670213
    Data columns (total 22 columns):
     #   Column                  Non-Null Count    Dtype  
    ---  ------                  --------------    -----  
     0   SK_ID_PREV              1670214 non-null  int64  
     1   SK_ID_CURR              1670214 non-null  int64  
     2   NAME_CONTRACT_TYPE      1670214 non-null  object 
     3   AMT_ANNUITY             1297979 non-null  float64
     4   AMT_APPLICATION         1670214 non-null  float64
     5   AMT_CREDIT              1670213 non-null  float64
     6   AMT_GOODS_PRICE         1284699 non-null  float64
     7   NAME_CASH_LOAN_PURPOSE  1670214 non-null  object 
     8   NAME_CONTRACT_STATUS    1670214 non-null  object 
     9   DAYS_DECISION           1670214 non-null  int64  
     10  NAME_PAYMENT_TYPE       1670214 non-null  object 
     11  CODE_REJECT_REASON      1670214 non-null  object 
     12  NAME_CLIENT_TYPE        1670214 non-null  object 
     13  NAME_GOODS_CATEGORY     1670214 non-null  object 
     14  NAME_PORTFOLIO          1670214 non-null  object 
     15  NAME_PRODUCT_TYPE       1670214 non-null  object 
     16  CHANNEL_TYPE            1670214 non-null  object 
     17  SELLERPLACE_AREA        1670214 non-null  int64  
     18  NAME_SELLER_INDUSTRY    1670214 non-null  object 
     19  CNT_PAYMENT             1297984 non-null  float64
     20  NAME_YIELD_GROUP        1670214 non-null  object 
     21  PRODUCT_COMBINATION     1669868 non-null  object 
    dtypes: float64(5), int64(4), object(13)
    memory usage: 280.3+ MB
    


```python
date_col = ['DAYS_BIRTH','DAYS_EMPLOYED','DAYS_REGISTRATION','DAYS_ID_PUBLISH']

for col in date_col:
    applicationdf[col] = abs(applicationdf[col])
```


```python
applicationdf['AMT_INCOME_TOTAL']=applicationdf['AMT_INCOME_TOTAL']/100000

bins = [0,1,2,3,4,5,6,7,8,9,10,11]
slot = ['0-100K','100K-200K', '200k-300k','300k-400k','400k-500k','500k-600k','600k-700k','700k-800k','800k-900k','900k-1M', '1M Above']

applicationdf['AMT_INCOME_RANGE']=pd.cut(applicationdf['AMT_INCOME_TOTAL'],bins,labels=slot)

```


```python
applicationdf['AMT_INCOME_RANGE'].value_counts(normalize=True)*100
```




    100K-200K    50.735000
    200k-300k    21.210691
    0-100K       20.729695
    300k-400k     4.776116
    400k-500k     1.744669
    500k-600k     0.356354
    600k-700k     0.282805
    800k-900k     0.096980
    700k-800k     0.052721
    900k-1M       0.009112
    1M Above      0.005858
    Name: AMT_INCOME_RANGE, dtype: float64




```python
applicationdf.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SK_ID_CURR</th>
      <th>TARGET</th>
      <th>NAME_CONTRACT_TYPE</th>
      <th>CODE_GENDER</th>
      <th>FLAG_OWN_CAR</th>
      <th>FLAG_OWN_REALTY</th>
      <th>CNT_CHILDREN</th>
      <th>AMT_INCOME_TOTAL</th>
      <th>AMT_CREDIT</th>
      <th>AMT_ANNUITY</th>
      <th>AMT_GOODS_PRICE</th>
      <th>NAME_TYPE_SUITE</th>
      <th>NAME_INCOME_TYPE</th>
      <th>NAME_EDUCATION_TYPE</th>
      <th>NAME_FAMILY_STATUS</th>
      <th>NAME_HOUSING_TYPE</th>
      <th>REGION_POPULATION_RELATIVE</th>
      <th>DAYS_BIRTH</th>
      <th>DAYS_EMPLOYED</th>
      <th>DAYS_REGISTRATION</th>
      <th>DAYS_ID_PUBLISH</th>
      <th>OCCUPATION_TYPE</th>
      <th>CNT_FAM_MEMBERS</th>
      <th>REGION_RATING_CLIENT</th>
      <th>REGION_RATING_CLIENT_W_CITY</th>
      <th>WEEKDAY_APPR_PROCESS_START</th>
      <th>HOUR_APPR_PROCESS_START</th>
      <th>REG_REGION_NOT_LIVE_REGION</th>
      <th>REG_REGION_NOT_WORK_REGION</th>
      <th>LIVE_REGION_NOT_WORK_REGION</th>
      <th>REG_CITY_NOT_LIVE_CITY</th>
      <th>REG_CITY_NOT_WORK_CITY</th>
      <th>LIVE_CITY_NOT_WORK_CITY</th>
      <th>ORGANIZATION_TYPE</th>
      <th>OBS_30_CNT_SOCIAL_CIRCLE</th>
      <th>DEF_30_CNT_SOCIAL_CIRCLE</th>
      <th>OBS_60_CNT_SOCIAL_CIRCLE</th>
      <th>DEF_60_CNT_SOCIAL_CIRCLE</th>
      <th>DAYS_LAST_PHONE_CHANGE</th>
      <th>FLAG_DOCUMENT_3</th>
      <th>AMT_REQ_CREDIT_BUREAU_HOUR</th>
      <th>AMT_REQ_CREDIT_BUREAU_DAY</th>
      <th>AMT_REQ_CREDIT_BUREAU_WEEK</th>
      <th>AMT_REQ_CREDIT_BUREAU_MON</th>
      <th>AMT_REQ_CREDIT_BUREAU_QRT</th>
      <th>AMT_REQ_CREDIT_BUREAU_YEAR</th>
      <th>AMT_INCOME_RANGE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>100002</td>
      <td>1</td>
      <td>Cash loans</td>
      <td>M</td>
      <td>N</td>
      <td>Y</td>
      <td>0</td>
      <td>2.025</td>
      <td>406597.5</td>
      <td>24700.5</td>
      <td>351000.0</td>
      <td>Unaccompanied</td>
      <td>Working</td>
      <td>Secondary / secondary special</td>
      <td>Single / not married</td>
      <td>House / apartment</td>
      <td>0.018801</td>
      <td>9461</td>
      <td>637</td>
      <td>3648.0</td>
      <td>2120</td>
      <td>Laborers</td>
      <td>1.0</td>
      <td>2</td>
      <td>2</td>
      <td>WEDNESDAY</td>
      <td>10</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Business Entity Type 3</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>-1134.0</td>
      <td>1</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>200k-300k</td>
    </tr>
    <tr>
      <th>1</th>
      <td>100003</td>
      <td>0</td>
      <td>Cash loans</td>
      <td>F</td>
      <td>N</td>
      <td>N</td>
      <td>0</td>
      <td>2.700</td>
      <td>1293502.5</td>
      <td>35698.5</td>
      <td>1129500.0</td>
      <td>Family</td>
      <td>State servant</td>
      <td>Higher education</td>
      <td>Married</td>
      <td>House / apartment</td>
      <td>0.003541</td>
      <td>16765</td>
      <td>1188</td>
      <td>1186.0</td>
      <td>291</td>
      <td>Core staff</td>
      <td>2.0</td>
      <td>1</td>
      <td>1</td>
      <td>MONDAY</td>
      <td>11</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>School</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>-828.0</td>
      <td>1</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>200k-300k</td>
    </tr>
    <tr>
      <th>2</th>
      <td>100004</td>
      <td>0</td>
      <td>Revolving loans</td>
      <td>M</td>
      <td>Y</td>
      <td>Y</td>
      <td>0</td>
      <td>0.675</td>
      <td>135000.0</td>
      <td>6750.0</td>
      <td>135000.0</td>
      <td>Unaccompanied</td>
      <td>Working</td>
      <td>Secondary / secondary special</td>
      <td>Single / not married</td>
      <td>House / apartment</td>
      <td>0.010032</td>
      <td>19046</td>
      <td>225</td>
      <td>4260.0</td>
      <td>2531</td>
      <td>Laborers</td>
      <td>1.0</td>
      <td>2</td>
      <td>2</td>
      <td>MONDAY</td>
      <td>9</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Government</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>-815.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0-100K</td>
    </tr>
    <tr>
      <th>3</th>
      <td>100006</td>
      <td>0</td>
      <td>Cash loans</td>
      <td>F</td>
      <td>N</td>
      <td>Y</td>
      <td>0</td>
      <td>1.350</td>
      <td>312682.5</td>
      <td>29686.5</td>
      <td>297000.0</td>
      <td>Unaccompanied</td>
      <td>Working</td>
      <td>Secondary / secondary special</td>
      <td>Civil marriage</td>
      <td>House / apartment</td>
      <td>0.008019</td>
      <td>19005</td>
      <td>3039</td>
      <td>9833.0</td>
      <td>2437</td>
      <td>Laborers</td>
      <td>2.0</td>
      <td>2</td>
      <td>2</td>
      <td>WEDNESDAY</td>
      <td>17</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Business Entity Type 3</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>-617.0</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>100K-200K</td>
    </tr>
    <tr>
      <th>4</th>
      <td>100007</td>
      <td>0</td>
      <td>Cash loans</td>
      <td>M</td>
      <td>N</td>
      <td>Y</td>
      <td>0</td>
      <td>1.215</td>
      <td>513000.0</td>
      <td>21865.5</td>
      <td>513000.0</td>
      <td>Unaccompanied</td>
      <td>Working</td>
      <td>Secondary / secondary special</td>
      <td>Single / not married</td>
      <td>House / apartment</td>
      <td>0.028663</td>
      <td>19932</td>
      <td>3038</td>
      <td>4311.0</td>
      <td>3458</td>
      <td>Core staff</td>
      <td>1.0</td>
      <td>2</td>
      <td>2</td>
      <td>THURSDAY</td>
      <td>11</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>Religion</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>-1106.0</td>
      <td>0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>100K-200K</td>
    </tr>
  </tbody>
</table>
</div>




```python
Imbalance = applicationdf["TARGET"].value_counts().reset_index()

plt.figure(figsize=(10,4))
x= ['Repayer','Defaulter']
sns.barplot(x,"TARGET",data = Imbalance,palette= ['g','r'])
plt.xlabel("Loan Repayment Status")
plt.ylabel("Count of Repayers & Defaulters")
plt.title("Imbalance Plotting")
plt.show()
```


    
![png](output_43_0.png)
    



```python
count_0 = Imbalance.iloc[0]["TARGET"]
count_1 = Imbalance.iloc[1]["TARGET"]
count_0_perc = round(count_0/(count_0+count_1)*100,2)
count_1_perc = round(count_1/(count_0+count_1)*100,2)

print('Ratios of imbalance in percentage with respect to Repayer and Defaulter datas are: %.2f and %.2f'%(count_0_perc,count_1_perc))
print('Ratios of imbalance in relative with respect to Repayer and Defaulter datas is %.2f : 1 (approx)'%(count_0/count_1))
```

    Ratios of imbalance in percentage with respect to Repayer and Defaulter datas are: 91.93 and 8.07
    Ratios of imbalance in relative with respect to Repayer and Defaulter datas is 11.39 : 1 (approx)
    


```python
def univariate_categorical(feature,ylog=False,label_rotation=False,horizontal_layout=True):
    temp = applicationDF[feature].value_counts()
    df1 = pd.DataFrame({feature: temp.index,'Number of contracts': temp.values})
```


```python

```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    ~\AppData\Local\Temp/ipykernel_12360/1875793640.py in <module>
    ----> 1 cat_perc = applicationdf[[feature, 'TARGET']].groupby([feature],as_index=False).mean()
          2 cat_perc["TARGET"] = cat_perc["TARGET"]*100
          3 cat_perc.sort_values(by='TARGET', ascending=False, inplace=True)
    

    NameError: name 'feature' is not defined



```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
